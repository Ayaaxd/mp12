class AuthService {
  Future<bool> signIn(String email, String password) async {
    await Future.delayed(const Duration(milliseconds: 500));
    
    if (email.isNotEmpty && password.length >= 6) {
      return true;
    }
    return false;
  }

  Future<void> signOut() async {
    await Future.delayed(const Duration(milliseconds: 200));
  }

  Future<Map<String, dynamic>?> getCurrentUser() async {
    await Future.delayed(const Duration(milliseconds: 100));
    return {'email': 'test@example.com', 'name': 'Test User'};
  }
}

class AuthController {
  final AuthService _authService;
  bool _isAuthenticated = false;
  String? _errorMessage;

  AuthController(this._authService);

  bool get isAuthenticated => _isAuthenticated;
  String? get errorMessage => _errorMessage;

  Future<bool> login(String email, String password) async {
    try {
      _errorMessage = null;
      
      if (email.isEmpty) {
        _errorMessage = 'Email cannot be empty';
        return false;
      }
      
      if (password.isEmpty) {
        _errorMessage = 'Password cannot be empty';
        return false;
      }

      final result = await _authService.signIn(email, password);
      
      if (result) {
        _isAuthenticated = true;
        return true;
      } else {
        _errorMessage = 'Invalid credentials';
        _isAuthenticated = false;
        return false;
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
      _isAuthenticated = false;
      return false;
    }
  }

  Future<void> logout() async {
    await _authService.signOut();
    _isAuthenticated = false;
    _errorMessage = null;
  }
}
