import 'package:flutter/material.dart';
import 'screens/counter_screen.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/buggy_screen.dart';
import 'screens/rebuild_demo_screen.dart';
import 'screens/performance_demo_screen.dart';
import 'screens/responsive_layout_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Testing Lab',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const MainMenuScreen(),
        '/counter': (context) => const CounterScreen(),
        '/login': (context) => const LoginScreen(),
        '/home': (context) => const HomeScreen(),
        '/buggy': (context) => const BuggyScreen(),
        '/rebuild-demo': (context) => const RebuildDemoScreen(),
        '/performance': (context) => const PerformanceDemoScreen(),
        '/responsive': (context) => const ResponsiveLayoutScreen(),
      },
    );
  }
}

class MainMenuScreen extends StatelessWidget {
  const MainMenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter Testing Lab'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          _buildMenuCard(
            context,
            'Task 2: Counter App',
            'Widget test demonstration',
            '/counter',
            Icons.add_circle,
          ),
          _buildMenuCard(
            context,
            'Task 3: Login Form',
            'Form validation testing',
            '/login',
            Icons.login,
          ),
          _buildMenuCard(
            context,
            'Task 5: Buggy Screen',
            'Null crash debugging',
            '/buggy',
            Icons.bug_report,
          ),
          _buildMenuCard(
            context,
            'Task 6: Rebuild Demo',
            'Excessive rebuilds analysis',
            '/rebuild-demo',
            Icons.refresh,
          ),
          _buildMenuCard(
            context,
            'Task 9: Performance Demo',
            'Performance profiling',
            '/performance',
            Icons.speed,
          ),
          _buildMenuCard(
            context,
            'Task 10: Responsive Layout',
            'Cross-device testing',
            '/responsive',
            Icons.devices,
          ),
        ],
      ),
    );
  }

  Widget _buildMenuCard(
    BuildContext context,
    String title,
    String subtitle,
    String route,
    IconData icon,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12.0),
      child: ListTile(
        leading: Icon(icon, size: 36, color: Theme.of(context).colorScheme.primary),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.arrow_forward_ios),
        onTap: () => Navigator.pushNamed(context, route),
      ),
    );
  }
}
