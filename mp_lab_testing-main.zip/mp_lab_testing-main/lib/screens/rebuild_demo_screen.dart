import 'package:flutter/material.dart';

int _buildCounter = 0;

class RebuildDemoScreen extends StatefulWidget {
  const RebuildDemoScreen({super.key});

  @override
  State<RebuildDemoScreen> createState() => _RebuildDemoScreenState();
}

class _RebuildDemoScreenState extends State<RebuildDemoScreen> {
  int _counter = 0;
  bool _showOptimized = false;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  void _toggleVersion() {
    setState(() {
      _showOptimized = !_showOptimized;
      _buildCounter = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rebuild Analysis'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Column(
        children: [
          Container(
            color: _showOptimized ? Colors.green[100] : Colors.red[100],
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _showOptimized ? 'Optimized Version' : 'Unoptimized Version',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                ElevatedButton(
                  onPressed: _toggleVersion,
                  child: const Text('Toggle Version'),
                ),
              ],
            ),
          ),
          Expanded(
            child: _showOptimized
                ? OptimizedContent(counter: _counter)
                : UnoptimizedContent(counter: _counter),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        child: const Icon(Icons.add),
      ),
    );
  }
}

class UnoptimizedContent extends StatelessWidget {
  final int counter;

  const UnoptimizedContent({super.key, required this.counter});

  @override
  Widget build(BuildContext context) {
    _buildCounter++;
    debugPrint('UnoptimizedContent built: $_buildCounter times');

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Card(
            color: Colors.red[50],
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Text(
                    'Build Count: $_buildCounter',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text('This rebuilds every time!'),
                ],
              ),
            ),
          ),
          SizedBox(height: 16),

          ExpensiveWidget(data: 'Counter: $counter'),
          SizedBox(height: 16),

          HeavyComputationWidget(value: counter),
          SizedBox(height: 16),

          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.orange[50],
              border: Border.all(color: Colors.orange),
            ),
            child: Column(
              children: [
                Text('Nested Widget', style: TextStyle(fontSize: 18)),
                SizedBox(height: 8),
                Text('Rebuilds: $_buildCounter'),
                SizedBox(height: 8),
                ListView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: 5,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: Text('Item $index'),
                      subtitle: Text('Rebuilds unnecessarily'),
                    );
                  },
                ),
              ],
            ),
          ),
          SizedBox(height: 16),

          Card(
            color: Colors.blue[50],
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Problems:',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text('• Missing const constructors'),
                  Text('• Heavy computations in build method'),
                  Text('• Widgets not properly extracted'),
                  Text('• Everything rebuilds on state change'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class OptimizedContent extends StatelessWidget {
  final int counter;

  const OptimizedContent({super.key, required this.counter});

  @override
  Widget build(BuildContext context) {
    _buildCounter++;
    debugPrint('OptimizedContent built: $_buildCounter times');

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Card(
            color: Color(0xFFC8E6C9),
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: _StaticHeader(),
            ),
          ),
          const SizedBox(height: 16),

          _DynamicCounter(counter: counter, buildCount: _buildCounter),
          const SizedBox(height: 16),

          const _OptimizedExpensiveWidget(),
          const SizedBox(height: 16),

          const _OptimizedListSection(),
          const SizedBox(height: 16),

          const Card(
            color: Color(0xFFE1F5FE),
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: _OptimizationTips(),
            ),
          ),
        ],
      ),
    );
  }
}

class _StaticHeader extends StatelessWidget {
  const _StaticHeader();

  @override
  Widget build(BuildContext context) {
    debugPrint('StaticHeader built (should be once)');
    return const Column(
      children: [
        Text(
          'Optimized Version',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 8),
        Text('Only necessary parts rebuild!'),
      ],
    );
  }
}

class _DynamicCounter extends StatelessWidget {
  final int counter;
  final int buildCount;

  const _DynamicCounter({required this.counter, required this.buildCount});

  @override
  Widget build(BuildContext context) {
    debugPrint('DynamicCounter built');
    return Card(
      color: Colors.green[50],
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              'Counter: $counter',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text('Build Count: $buildCount'),
          ],
        ),
      ),
    );
  }
}

class _OptimizedExpensiveWidget extends StatelessWidget {
  const _OptimizedExpensiveWidget();

  @override
  Widget build(BuildContext context) {
    debugPrint('OptimizedExpensiveWidget built (should be once)');
    return const Card(
      color: Color(0xFFFFF9C4), // Colors.yellow[100] equivalent
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Text(
          '✓ This widget doesn\'t rebuild',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}

class _OptimizedListSection extends StatelessWidget {
  const _OptimizedListSection();

  @override
  Widget build(BuildContext context) {
    debugPrint('OptimizedListSection built (should be once)');
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.purple[50],
        border: Border.all(color: Colors.purple),
      ),
      child: Column(
        children: [
          const Text('Optimized List', style: TextStyle(fontSize: 18)),
          const SizedBox(height: 8),
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 5,
            itemBuilder: (context, index) {
              return const _ListItemWidget();
            },
          ),
        ],
      ),
    );
  }
}

class _ListItemWidget extends StatelessWidget {
  const _ListItemWidget();

  @override
  Widget build(BuildContext context) {
    return const ListTile(
      title: Text('Optimized Item'),
      subtitle: Text('Uses const constructor'),
    );
  }
}

class _OptimizationTips extends StatelessWidget {
  const _OptimizationTips();

  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Optimizations Applied:',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 8),
        Text('✓ Used const constructors everywhere possible'),
        Text('✓ Extracted widgets into separate classes'),
        Text('✓ Moved heavy computations outside build'),
        Text('✓ Only dynamic data causes rebuilds'),
        SizedBox(height: 8),
        Text(
          'Result: Fewer rebuilds, better performance!',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green),
        ),
      ],
    );
  }
}

class ExpensiveWidget extends StatelessWidget {
  final String data;

  const ExpensiveWidget({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    debugPrint('ExpensiveWidget rebuilt!');
    _doHeavyWork();

    return Card(
      color: Colors.yellow[50],
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Text(
          data,
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }

  void _doHeavyWork() {
    int sum = 0;
    for (int i = 0; i < 1000; i++) {
      sum += i;
    }
  }
}

class HeavyComputationWidget extends StatelessWidget {
  final int value;

  const HeavyComputationWidget({super.key, required this.value});

  @override
  Widget build(BuildContext context) {
    debugPrint('HeavyComputationWidget rebuilt!');
    
    final result = _expensiveCalculation(value);

    return Card(
      color: Colors.purple[50],
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Text(
          'Calculation result: $result',
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }

  int _expensiveCalculation(int n) {
    int result = 0;
    for (int i = 0; i < 10000; i++) {
      result += n * i;
    }
    return result % 1000;
  }
}
