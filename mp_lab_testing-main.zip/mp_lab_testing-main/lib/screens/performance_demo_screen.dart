import 'package:flutter/material.dart';
import 'dart:math';

class PerformanceDemoScreen extends StatefulWidget {
  const PerformanceDemoScreen({super.key});

  @override
  State<PerformanceDemoScreen> createState() => _PerformanceDemoScreenState();
}

class _PerformanceDemoScreenState extends State<PerformanceDemoScreen> {
  bool _useOptimized = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Performance Demo'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Column(
        children: [
          Container(
            color: _useOptimized ? Colors.green[100] : Colors.red[100],
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      _useOptimized ? 'Optimized Version ✓' : 'Slow Version ⚠',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Switch(
                      value: _useOptimized,
                      onChanged: (value) {
                        setState(() {
                          _useOptimized = value;
                        });
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  _useOptimized
                      ? 'Smooth scrolling with optimizations'
                      : 'Janky scrolling with performance issues',
                  style: const TextStyle(fontSize: 14),
                ),
              ],
            ),
          ),
          Expanded(
            child: _useOptimized
                ? const OptimizedListView()
                : const SlowListView(),
          ),
        ],
      ),
    );
  }
}

class SlowListView extends StatelessWidget {
  const SlowListView({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 100,
      itemBuilder: (context, index) {
        final randomColor = _generateRandomColor();
        
        final complexData = _doExpensiveSync();
        
        return Card(
          margin: EdgeInsets.all(8.0),
          child: ListTile(
            leading: Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: randomColor,
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [randomColor, randomColor.withOpacity(0.5)],
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 5,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  '${index + 1}',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            title: Text(
              'Item ${index + 1}',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Complex calculation: $complexData'),
                SizedBox(height: 4),
                Text('Fibonacci: ${_fibonacci(20)}'),
              ],
            ),
            trailing: Icon(Icons.arrow_forward_ios),
          ),
        );
      },
    );
  }

  String _doExpensiveSync() {
    int sum = 0;
    for (int i = 0; i < 100000; i++) {
      sum += i * Random().nextInt(10);
    }
    return sum.toString().substring(0, min(5, sum.toString().length));
  }

  int _fibonacci(int n) {
    if (n <= 1) return n;
    return _fibonacci(n - 1) + _fibonacci(n - 2);
  }

  Color _generateRandomColor() {
    return Color.fromRGBO(
      Random().nextInt(256),
      Random().nextInt(256),
      Random().nextInt(256),
      1,
    );
  }
}

class OptimizedListView extends StatelessWidget {
  const OptimizedListView({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 100,
      itemExtent: 100,
      cacheExtent: 200,
      itemBuilder: (context, index) {
        return OptimizedListItem(index: index);
      },
    );
  }
}

class OptimizedListItem extends StatelessWidget {
  final int index;

  const OptimizedListItem({super.key, required this.index});

  static final List<Color> _colorPalette = [
    Colors.blue,
    Colors.green,
    Colors.orange,
    Colors.purple,
    Colors.red,
    Colors.teal,
    Colors.amber,
    Colors.indigo,
  ];

  static final Map<int, int> _fibCache = {
    0: 0,
    1: 1,
    10: 55,
    15: 610,
    20: 6765,
  };

  @override
  Widget build(BuildContext context) {
    final color = _colorPalette[index % _colorPalette.length];
    
    return Card(
      margin: const EdgeInsets.all(8.0),
      child: ListTile(
        leading: Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              '${index + 1}',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        title: Text(
          'Item ${index + 1}',
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Index: ${index.toString().padLeft(3, '0')}'),
            const SizedBox(height: 4),
            Text('Fibonacci(20): ${_fibCache[20]}'),
          ],
        ),
        trailing: const Icon(Icons.arrow_forward_ios),
      ),
    );
  }
}
