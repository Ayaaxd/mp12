import 'package:flutter/material.dart';

class BuggyScreen extends StatefulWidget {
  const BuggyScreen({super.key});

  @override
  State<BuggyScreen> createState() => _BuggyScreenState();
}

class _BuggyScreenState extends State<BuggyScreen> {
  UserData? userData;
  
  List<String>? items;
  
  TextEditingController? nameController;

  @override
  void initState() {
    super.initState();
  }

  void _initializeData() {
    userData = UserData(name: 'John Doe', age: 25);
    items = ['Item 1', 'Item 2', 'Item 3'];
    nameController = TextEditingController();
  }

  @override
  void dispose() {
    nameController?.dispose();
    super.dispose();
  }

  String getUserInfo() {
    return 'Name: ${userData!.name}, Age: ${userData!.age}';
  }

  int getItemCount() {
    return items!.length;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Buggy Screen - Null Errors'),
        backgroundColor: Colors.red[300],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Debugging Exercise',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'This screen contains null pointer errors. Try to reproduce the crashes!',
              style: TextStyle(color: Colors.red),
            ),
            const Divider(height: 32),
            
            ElevatedButton(
              onPressed: () {
                try {
                  final info = getUserInfo();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(info)),
                  );
                } catch (e) {
                  _showError(context, 'Bug 1', e.toString());
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Trigger Bug 1: Access Null User Data'),
            ),
            const SizedBox(height: 12),
            
            ElevatedButton(
              onPressed: () {
                try {
                  final count = getItemCount();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Item count: $count')),
                  );
                } catch (e) {
                  _showError(context, 'Bug 2', e.toString());
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Trigger Bug 2: Access Null List'),
            ),
            const SizedBox(height: 12),
            
            ElevatedButton(
              onPressed: () {
                try {
                  final text = nameController!.text;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Text: $text')),
                  );
                } catch (e) {
                  _showError(context, 'Bug 3', e.toString());
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Trigger Bug 3: Access Null Controller'),
            ),
            const SizedBox(height: 12),
            
            ElevatedButton(
              onPressed: () {
                try {
                  final displayAge = userData!.age * 2;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Double age: $displayAge')),
                  );
                } catch (e) {
                  _showError(context, 'Bug 4', e.toString());
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Trigger Bug 4: Calculate with Null'),
            ),
            const Divider(height: 32),
            
            Card(
              color: Colors.blue[50],
              child: const Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Instructions:',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8),
                    Text('1. Tap each button to reproduce crashes'),
                    Text('2. Check the error messages displayed'),
                    Text('3. Review the stack trace in the console'),
                    Text('4. Identify the null variables'),
                    Text('5. Apply fixes using null-checks or initialization'),
                    SizedBox(height: 12),
                    Text(
                      'Hint: Uncomment _initializeData() in initState()',
                      style: TextStyle(fontStyle: FontStyle.italic, color: Colors.blue),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const FixedScreen()),
                );
              },
              icon: const Icon(Icons.check_circle),
              label: const Text('View Fixed Version'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            ),
          ],
        ),
      ),
    );
  }

  void _showError(BuildContext context, String bugName, String error) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(bugName),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Error caught:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              error,
              style: const TextStyle(color: Colors.red, fontFamily: 'monospace'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
}

class UserData {
  final String name;
  final int age;

  UserData({required this.name, required this.age});
}

class FixedScreen extends StatefulWidget {
  const FixedScreen({super.key});

  @override
  State<FixedScreen> createState() => _FixedScreenState();
}

class _FixedScreenState extends State<FixedScreen> {
  late UserData userData;
  late List<String> items;
  late TextEditingController nameController;

  @override
  void initState() {
    super.initState();
    _initializeData();
  }

  void _initializeData() {
    userData = UserData(name: 'John Doe', age: 25);
    items = ['Item 1', 'Item 2', 'Item 3'];
    nameController = TextEditingController(text: 'Sample text');
  }

  @override
  void dispose() {
    nameController.dispose();
    super.dispose();
  }

  String getUserInfo() {
    return 'Name: ${userData.name}, Age: ${userData.age}';
  }

  int getItemCount() {
    return items.length;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Fixed Screen'),
        backgroundColor: Colors.green[300],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Fixed Version',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'All null safety issues have been resolved!',
              style: TextStyle(color: Colors.green),
            ),
            const Divider(height: 32),
            
            ElevatedButton(
              onPressed: () {
                final info = getUserInfo();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(info)),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              child: const Text('✓ Get User Data (Fixed)'),
            ),
            const SizedBox(height: 12),
            
            ElevatedButton(
              onPressed: () {
                final count = getItemCount();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Item count: $count')),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              child: const Text('✓ Get Item Count (Fixed)'),
            ),
            const SizedBox(height: 12),
            
            ElevatedButton(
              onPressed: () {
                final text = nameController.text;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Text: $text')),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              child: const Text('✓ Get Controller Text (Fixed)'),
            ),
            const SizedBox(height: 12),
            
            ElevatedButton(
              onPressed: () {
                final displayAge = userData.age * 2;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Double age: $displayAge')),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              child: const Text('✓ Calculate with Data (Fixed)'),
            ),
            const Divider(height: 32),
            
            Card(
              color: Colors.green[50],
              child: const Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Fixes Applied:',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8),
                    Text('✓ All variables properly initialized in initState()'),
                    Text('✓ Used late keyword for non-nullable fields'),
                    Text('✓ Removed null assertion operators (!)'),
                    Text('✓ Added proper null-safety checks'),
                    Text('✓ Ensured controllers are disposed'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
