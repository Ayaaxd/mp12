import 'package:flutter/material.dart';

class ResponsiveLayoutScreen extends StatelessWidget {
  const ResponsiveLayoutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Responsive Layout'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: const ResponsiveLayout(),
    );
  }
}

class ResponsiveLayout extends StatelessWidget {
  const ResponsiveLayout({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final orientation = MediaQuery.of(context).orientation;
    
    final deviceType = _getDeviceType(size.width);

    return SingleChildScrollView(
      child: Column(
        children: [
          _DeviceInfoHeader(
            size: size,
            orientation: orientation,
            deviceType: deviceType,
          ),
          
          _ResponsiveGrid(deviceType: deviceType),
          
          const SizedBox(height: 16),
          
          _ResponsiveCardLayout(deviceType: deviceType),
          
          const SizedBox(height: 16),
          
          _AdaptiveNavigationExample(deviceType: deviceType),
          
          const SizedBox(height: 16),
          
          const _ResponsiveLayoutTips(),
        ],
      ),
    );
  }

  DeviceType _getDeviceType(double width) {
    if (width < 600) {
      return DeviceType.smallPhone;
    } else if (width < 900) {
      return DeviceType.largePhone;
    } else if (width < 1200) {
      return DeviceType.tablet;
    } else {
      return DeviceType.desktop;
    }
  }
}

enum DeviceType { smallPhone, largePhone, tablet, desktop }

class _DeviceInfoHeader extends StatelessWidget {
  final Size size;
  final Orientation orientation;
  final DeviceType deviceType;

  const _DeviceInfoHeader({
    required this.size,
    required this.orientation,
    required this.deviceType,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16.0),
      color: Colors.blue[100],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Device Information',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 8),
          Text('Screen Size: ${size.width.toInt()} x ${size.height.toInt()}'),
          Text('Orientation: ${orientation.name}'),
          Text('Device Type: ${_deviceTypeName(deviceType)}'),
          Text('Breakpoint: ${_getBreakpoint(size.width)}'),
        ],
      ),
    );
  }

  String _deviceTypeName(DeviceType type) {
    switch (type) {
      case DeviceType.smallPhone:
        return 'Small Phone (<600)';
      case DeviceType.largePhone:
        return 'Large Phone (600-900)';
      case DeviceType.tablet:
        return 'Tablet (900-1200)';
      case DeviceType.desktop:
        return 'Desktop (>1200)';
    }
  }

  String _getBreakpoint(double width) {
    if (width < 600) return 'xs';
    if (width < 900) return 'sm';
    if (width < 1200) return 'md';
    return 'lg';
  }
}

class _ResponsiveGrid extends StatelessWidget {
  final DeviceType deviceType;

  const _ResponsiveGrid({required this.deviceType});

  @override
  Widget build(BuildContext context) {
    final crossAxisCount = _getCrossAxisCount(deviceType);
    
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Responsive Grid ($crossAxisCount columns)',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: crossAxisCount,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.2,
            ),
            itemCount: 6,
            itemBuilder: (context, index) {
              return Container(
                decoration: BoxDecoration(
                  color: Colors.primaries[index % Colors.primaries.length],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(
                    'Item ${index + 1}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  int _getCrossAxisCount(DeviceType type) {
    switch (type) {
      case DeviceType.smallPhone:
        return 2;
      case DeviceType.largePhone:
        return 3;
      case DeviceType.tablet:
        return 4;
      case DeviceType.desktop:
        return 6;
    }
  }
}

class _ResponsiveCardLayout extends StatelessWidget {
  final DeviceType deviceType;

  const _ResponsiveCardLayout({required this.deviceType});

  @override
  Widget build(BuildContext context) {
    final isCompact = deviceType == DeviceType.smallPhone;
    
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Adaptive Card Layout',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          isCompact
              ? const _CompactCard()
              : const _ExpandedCard(),
        ],
      ),
    );
  }
}

class _CompactCard extends StatelessWidget {
  const _CompactCard();

  @override
  Widget build(BuildContext context) {
    return const Card(
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.smartphone, size: 48, color: Colors.blue),
            SizedBox(height: 12),
            Text(
              'Compact Layout',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text('Vertical layout for small screens'),
          ],
        ),
      ),
    );
  }
}

class _ExpandedCard extends StatelessWidget {
  const _ExpandedCard();

  @override
  Widget build(BuildContext context) {
    return const Card(
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Row(
          children: [
            Icon(Icons.tablet, size: 64, color: Colors.green),
            SizedBox(width: 24),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Expanded Layout',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text('Horizontal layout for larger screens with more space'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AdaptiveNavigationExample extends StatelessWidget {
  final DeviceType deviceType;

  const _AdaptiveNavigationExample({required this.deviceType});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Adaptive Navigation',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Text(
                    _getNavigationDescription(deviceType),
                    style: const TextStyle(fontSize: 16),
                  ),
                  const SizedBox(height: 16),
                  _buildNavigationExample(deviceType),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _getNavigationDescription(DeviceType type) {
    switch (type) {
      case DeviceType.smallPhone:
      case DeviceType.largePhone:
        return 'Bottom Navigation Bar for mobile devices';
      case DeviceType.tablet:
        return 'Navigation Rail for tablets';
      case DeviceType.desktop:
        return 'Permanent Drawer for desktop';
    }
  }

  Widget _buildNavigationExample(DeviceType type) {
    switch (type) {
      case DeviceType.smallPhone:
      case DeviceType.largePhone:
        return Container(
          height: 56,
          decoration: BoxDecoration(
            color: Colors.blue[50],
            border: Border.all(color: Colors.blue),
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Icon(Icons.home),
              Icon(Icons.search),
              Icon(Icons.favorite),
              Icon(Icons.person),
            ],
          ),
        );
      case DeviceType.tablet:
        return Container(
          height: 200,
          decoration: BoxDecoration(
            color: Colors.green[50],
            border: Border.all(color: Colors.green),
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Row(
            children: [
              SizedBox(
                width: 72,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Icon(Icons.home, size: 32),
                    Icon(Icons.search, size: 32),
                    Icon(Icons.favorite, size: 32),
                    Icon(Icons.person, size: 32),
                  ],
                ),
              ),
              VerticalDivider(thickness: 2),
              Expanded(
                child: Center(
                  child: Text('Content Area'),
                ),
              ),
            ],
          ),
        );
      case DeviceType.desktop:
        return Container(
          height: 200,
          decoration: BoxDecoration(
            color: Colors.purple[50],
            border: Border.all(color: Colors.purple),
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Row(
            children: [
              SizedBox(
                width: 200,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ListTile(leading: Icon(Icons.home), title: Text('Home')),
                    ListTile(leading: Icon(Icons.search), title: Text('Search')),
                    ListTile(leading: Icon(Icons.favorite), title: Text('Favorites')),
                    ListTile(leading: Icon(Icons.person), title: Text('Profile')),
                  ],
                ),
              ),
              VerticalDivider(thickness: 2),
              Expanded(
                child: Center(
                  child: Text('Content Area'),
                ),
              ),
            ],
          ),
        );
    }
  }
}

class _ResponsiveLayoutTips extends StatelessWidget {
  const _ResponsiveLayoutTips();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Card(
        color: Colors.amber[50],
        child: const Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Responsive Design Techniques:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 12),
              Text('✓ MediaQuery for screen dimensions'),
              Text('✓ LayoutBuilder for parent constraints'),
              Text('✓ Flexible & Expanded for flexible layouts'),
              Text('✓ FittedBox to prevent overflow'),
              Text('✓ AspectRatio for consistent proportions'),
              Text('✓ OrientationBuilder for orientation changes'),
              SizedBox(height: 12),
              Text(
                'Breakpoints Used:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text('• Small Phone: < 600px'),
              Text('• Large Phone: 600-900px'),
              Text('• Tablet: 900-1200px'),
              Text('• Desktop: > 1200px'),
            ],
          ),
        ),
      ),
    );
  }
}
