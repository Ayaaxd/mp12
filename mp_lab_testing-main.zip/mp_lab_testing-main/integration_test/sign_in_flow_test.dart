import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:mp_lab_testing/main.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('Sign-In Flow Integration Test', () {
    testWidgets('complete sign-in flow from login to home screen',
        (WidgetTester tester) async {
      app.main();
      await tester.pumpAndSettle();

      expect(find.text('Flutter Testing Lab'), findsOneWidget);

      await tester.tap(find.text('Task 3: Login Form'));
      await tester.pumpAndSettle();

      expect(find.text('Welcome Back'), findsOneWidget);

      final emailField = find.byKey(const Key('email_field'));
      expect(emailField, findsOneWidget);
      await tester.enterText(emailField, 'test@example.com');
      await tester.pumpAndSettle();

      final passwordField = find.byKey(const Key('password_field'));
      expect(passwordField, findsOneWidget);
      await tester.enterText(passwordField, 'password123');
      await tester.pumpAndSettle();

      expect(find.text('test@example.com'), findsOneWidget);
      expect(find.text('password123'), findsNothing);

      final signInButton = find.byKey(const Key('submit_button'));
      expect(signInButton, findsOneWidget);

      await tester.pumpAndSettle(const Duration(milliseconds: 500));

      await tester.tap(signInButton);
      
      await tester.pumpAndSettle(const Duration(seconds: 2));

      expect(find.text('Login Successful!'), findsOneWidget);
      expect(find.byKey(const Key('success_text')), findsOneWidget);
      expect(find.text('Welcome to the Home Screen'), findsOneWidget);
    });

    testWidgets('sign-in with invalid credentials shows error',
        (WidgetTester tester) async {
      app.main();
      await tester.pumpAndSettle();

      await tester.tap(find.text('Task 3: Login Form'));
      await tester.pumpAndSettle();

      await tester.enterText(
        find.byKey(const Key('email_field')),
        'invalid-email',
      );
      await tester.enterText(
        find.byKey(const Key('password_field')),
        'password123',
      );
      await tester.pumpAndSettle();

      await tester.tap(find.byKey(const Key('submit_button')), warnIfMissed: false);
      await tester.pumpAndSettle();

      expect(find.text('Please enter a valid email'), findsOneWidget);
    });

    testWidgets('sign-in with empty fields shows validation errors',
        (WidgetTester tester) async {
      app.main();
      await tester.pumpAndSettle();

      await tester.tap(find.text('Task 3: Login Form'));
      await tester.pumpAndSettle();

      await tester.tap(find.byKey(const Key('submit_button')), warnIfMissed: false);
      await tester.pumpAndSettle();

      expect(find.text('Email is required'), findsOneWidget);
      expect(find.text('Password is required'), findsOneWidget);
    });

    testWidgets('complete user journey: menu -> login -> home -> back to menu',
        (WidgetTester tester) async {
      app.main();
      await tester.pumpAndSettle();

      expect(find.text('Flutter Testing Lab'), findsOneWidget);
      await tester.tap(find.text('Task 3: Login Form'));
      await tester.pumpAndSettle();

      await tester.enterText(
        find.byKey(const Key('email_field')),
        'user@example.com',
      );
      await tester.enterText(
        find.byKey(const Key('password_field')),
        'securepass',
      );
      await tester.pumpAndSettle(const Duration(milliseconds: 500));

      await tester.tap(find.byKey(const Key('submit_button')));
      await tester.pumpAndSettle(const Duration(seconds: 2));

      expect(find.text('Login Successful!'), findsOneWidget);

      await tester.tap(find.text('Back to Main Menu'));
      await tester.pumpAndSettle();

      expect(find.text('Flutter Testing Lab'), findsOneWidget);
      expect(find.text('Task 3: Login Form'), findsOneWidget);
    });

    testWidgets('navigate through multiple screens in the app',
        (WidgetTester tester) async {
      app.main();
      await tester.pumpAndSettle();

      await tester.tap(find.text('Task 2: Counter App'));
      await tester.pumpAndSettle();
      expect(find.text('Counter App'), findsOneWidget);
      await tester.tap(find.byType(BackButton));
      await tester.pumpAndSettle();

      await tester.tap(find.text('Task 3: Login Form'));
      await tester.pumpAndSettle();
      expect(find.text('Welcome Back'), findsOneWidget);
      await tester.tap(find.byType(BackButton));
      await tester.pumpAndSettle();

      expect(find.text('Flutter Testing Lab'), findsOneWidget);
    });
  });
}
