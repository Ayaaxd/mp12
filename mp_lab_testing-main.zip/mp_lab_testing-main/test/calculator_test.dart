import 'package:flutter_test/flutter_test.dart';
import 'package:mp_lab_testing/models/calculator.dart';

void main() {
  group('Calculator.add() tests', () {
    late Calculator calculator;

    setUp(() {
      calculator = Calculator();
    });

    test('adds two positive numbers correctly', () {
      const double num1 = 5.0;
      const double num2 = 3.0;
      const double expected = 8.0;

      final result = calculator.add(num1, num2);

      expect(result, equals(expected));
    });

    test('adds two negative numbers correctly', () {
      const double num1 = -5.0;
      const double num2 = -3.0;
      const double expected = -8.0;

      final result = calculator.add(num1, num2);

      expect(result, equals(expected));
    });

    test('adds positive and negative numbers correctly', () {
      const double num1 = 10.0;
      const double num2 = -3.0;
      const double expected = 7.0;

      final result = calculator.add(num1, num2);

      expect(result, equals(expected));
    });

    test('adds zero to a positive number correctly', () {
      const double num1 = 5.0;
      const double num2 = 0.0;
      const double expected = 5.0;

      final result = calculator.add(num1, num2);

      expect(result, equals(expected));
    });

    test('adds zero to a negative number correctly', () {
      const double num1 = -5.0;
      const double num2 = 0.0;
      const double expected = -5.0;

      final result = calculator.add(num1, num2);

      expect(result, equals(expected));
    });

    test('adds two zeros correctly', () {
      const double num1 = 0.0;
      const double num2 = 0.0;
      const double expected = 0.0;

      final result = calculator.add(num1, num2);

      expect(result, equals(expected));
    });

    test('adds decimal numbers correctly', () {
      const double num1 = 5.5;
      const double num2 = 3.3;
      const double expected = 8.8;

      final result = calculator.add(num1, num2);

      expect(result, closeTo(expected, 0.0001));
    });

    test('adds large numbers correctly', () {
      const double num1 = 1000000.0;
      const double num2 = 2000000.0;
      const double expected = 3000000.0;

      final result = calculator.add(num1, num2);

      expect(result, equals(expected));
    });

    test('adds mixed positive, negative, and zero values', () {
      const double num1 = 0.0;
      const double num2 = -10.0;
      const double expected = -10.0;

      final result = calculator.add(num1, num2);

      expect(result, equals(expected));
    });

    test('adds very small decimal numbers', () {
      const double num1 = 0.0001;
      const double num2 = 0.0002;
      const double expected = 0.0003;

      final result = calculator.add(num1, num2);

      expect(result, closeTo(expected, 0.00001));
    });
  });

  group('Calculator other operations', () {
    late Calculator calculator;

    setUp(() {
      calculator = Calculator();
    });

    test('subtracts two numbers correctly', () {
      expect(calculator.subtract(10.0, 3.0), equals(7.0));
    });

    test('multiplies two numbers correctly', () {
      expect(calculator.multiply(5.0, 3.0), equals(15.0));
    });

    test('divides two numbers correctly', () {
      expect(calculator.divide(10.0, 2.0), equals(5.0));
    });

    test('throws error when dividing by zero', () {
      expect(() => calculator.divide(10.0, 0.0), throwsArgumentError);
    });
  });
}
