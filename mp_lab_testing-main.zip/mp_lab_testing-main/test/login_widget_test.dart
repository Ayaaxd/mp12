import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mp_lab_testing/screens/login_screen.dart';

void main() {
  group('LoginScreen Validation Tests', () {
    testWidgets('displays email and password fields', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: LoginScreen(),
        ),
      );

      expect(find.byKey(const Key('email_field')), findsOneWidget);
      expect(find.byKey(const Key('password_field')), findsOneWidget);
      expect(find.byKey(const Key('submit_button')), findsOneWidget);
    });

    testWidgets('submit button is initially disabled', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: LoginScreen(),
        ),
      );

      final submitButton = tester.widget<ElevatedButton>(
        find.byKey(const Key('submit_button')),
      );

      expect(submitButton.onPressed, isNull);
    });

    testWidgets('shows error when email field is empty and submitted', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: LoginScreen(),
        ),
      );

      await tester.enterText(find.byKey(const Key('password_field')), 'password123');
      await tester.pump();

      final submitButtonFinder = find.byKey(const Key('submit_button'));
      await tester.tap(submitButtonFinder, warnIfMissed: false);
      await tester.pump();

      expect(find.text('Email is required'), findsOneWidget);
    });

    testWidgets('shows error when password field is empty and submitted', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: LoginScreen(),
        ),
      );

      await tester.enterText(find.byKey(const Key('email_field')), 'test@example.com');
      await tester.pump();

      final submitButtonFinder = find.byKey(const Key('submit_button'));
      await tester.tap(submitButtonFinder, warnIfMissed: false);
      await tester.pump();

      expect(find.text('Password is required'), findsOneWidget);
    });

    testWidgets('shows error for invalid email format', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: LoginScreen(),
        ),
      );

      await tester.enterText(find.byKey(const Key('email_field')), 'invalid-email');
      await tester.enterText(find.byKey(const Key('password_field')), 'password123');
      await tester.pump();

      final submitButtonFinder = find.byKey(const Key('submit_button'));
      await tester.tap(submitButtonFinder, warnIfMissed: false);
      await tester.pump();

      expect(find.text('Please enter a valid email'), findsOneWidget);
    });

    testWidgets('shows error for short password', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: LoginScreen(),
        ),
      );

      await tester.enterText(find.byKey(const Key('email_field')), 'test@example.com');
      await tester.enterText(find.byKey(const Key('password_field')), '12345');
      await tester.pump();

      final submitButtonFinder = find.byKey(const Key('submit_button'));
      await tester.tap(submitButtonFinder, warnIfMissed: false);
      await tester.pump();

      expect(find.text('Password must be at least 6 characters'), findsOneWidget);
    });

    testWidgets('submit button becomes enabled with valid data', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: LoginScreen(),
          routes: {
            '/home': (context) => const Scaffold(body: Text('Home')),
          },
        ),
      );

      await tester.enterText(find.byKey(const Key('email_field')), 'test@example.com');
      await tester.pump();
      await tester.enterText(find.byKey(const Key('password_field')), 'password123');
      await tester.pump();

      await tester.pumpAndSettle();

      final submitButton = tester.widget<ElevatedButton>(
        find.byKey(const Key('submit_button')),
      );
      expect(submitButton.onPressed, isNotNull);
    });

    testWidgets('validates multiple invalid email formats', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: LoginScreen(),
        ),
      );

      final invalidEmails = [
        'plaintext',
        '@example.com',
        'user@',
        'user @example.com',
        'user@.com',
      ];

      for (final email in invalidEmails) {
        await tester.enterText(find.byKey(const Key('email_field')), email);
        await tester.enterText(find.byKey(const Key('password_field')), 'password123');
        await tester.pump();

        final submitButtonFinder = find.byKey(const Key('submit_button'));
        await tester.tap(submitButtonFinder, warnIfMissed: false);
        await tester.pump();

        expect(find.text('Please enter a valid email'), findsOneWidget,
            reason: 'Failed for email: $email');
      }
    });

    testWidgets('navigates to home on successful submission', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: const LoginScreen(),
          routes: {
            '/home': (context) => const Scaffold(
                  body: Center(child: Text('Home Screen')),
                ),
          },
        ),
      );

      await tester.enterText(find.byKey(const Key('email_field')), 'user@example.com');
      await tester.enterText(find.byKey(const Key('password_field')), 'password123');
      await tester.pumpAndSettle();

      await tester.tap(find.byKey(const Key('submit_button')));
      await tester.pumpAndSettle();

      expect(find.text('Home Screen'), findsOneWidget);
    });

    testWidgets('forgot password button shows snackbar', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: LoginScreen(),
        ),
      );

      await tester.tap(find.byKey(const Key('forgot_password_button')));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 100));

      expect(find.text('Password reset not implemented'), findsOneWidget);
    });
  });
}
