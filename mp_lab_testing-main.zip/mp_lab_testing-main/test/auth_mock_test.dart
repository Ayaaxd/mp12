import 'package:flutter_test/flutter_test.dart';
import 'package:mp_lab_testing/services/auth_service.dart';

class MockAuthService implements AuthService {
  bool shouldSucceed = true;
  bool shouldThrowError = false;
  int signInCallCount = 0;
  int signOutCallCount = 0;

  @override
  Future<bool> signIn(String email, String password) async {
    signInCallCount++;
    
    if (shouldThrowError) {
      throw Exception('Network error');
    }
    
    await Future.delayed(Duration.zero);
    
    return shouldSucceed;
  }

  @override
  Future<void> signOut() async {
    signOutCallCount++;
    await Future.delayed(Duration.zero);
  }

  @override
  Future<Map<String, dynamic>?> getCurrentUser() async {
    await Future.delayed(Duration.zero);
    return {'email': 'mock@example.com', 'name': 'Mock User'};
  }
}

void main() {
  group('AuthController with Mock - Success Cases', () {
    late MockAuthService mockAuthService;
    late AuthController authController;

    setUp(() {
      mockAuthService = MockAuthService();
      mockAuthService.shouldSucceed = true;
      authController = AuthController(mockAuthService);
    });

    test('successful login sets authenticated state to true', () async {
      const email = 'test@example.com';
      const password = 'password123';

      final result = await authController.login(email, password);

      expect(result, isTrue);
      expect(authController.isAuthenticated, isTrue);
      expect(authController.errorMessage, isNull);
      expect(mockAuthService.signInCallCount, equals(1));
    });

    test('successful login with valid credentials', () async {
      mockAuthService.shouldSucceed = true;

      final result = await authController.login('user@test.com', 'securepass');

      expect(result, isTrue);
      expect(authController.isAuthenticated, isTrue);
    });

    test('logout clears authentication state', () async {
      await authController.login('test@example.com', 'password123');
      expect(authController.isAuthenticated, isTrue);

      await authController.logout();

      expect(authController.isAuthenticated, isFalse);
      expect(mockAuthService.signOutCallCount, equals(1));
    });
  });

  group('AuthController with Mock - Failure Cases', () {
    late MockAuthService mockAuthService;
    late AuthController authController;

    setUp(() {
      mockAuthService = MockAuthService();
      mockAuthService.shouldSucceed = false;
      authController = AuthController(mockAuthService);
    });

    test('failed login keeps authenticated state false', () async {
      mockAuthService.shouldSucceed = false;

      final result = await authController.login('test@example.com', 'wrongpass');

      expect(result, isFalse);
      expect(authController.isAuthenticated, isFalse);
      expect(authController.errorMessage, equals('Invalid credentials'));
    });

    test('login with empty email returns false and sets error', () async {
      const email = '';
      const password = 'password123';

      final result = await authController.login(email, password);

      expect(result, isFalse);
      expect(authController.isAuthenticated, isFalse);
      expect(authController.errorMessage, equals('Email cannot be empty'));
      expect(mockAuthService.signInCallCount, equals(0));
    });

    test('login with empty password returns false and sets error', () async {
      const email = 'test@example.com';
      const password = '';

      final result = await authController.login(email, password);

      expect(result, isFalse);
      expect(authController.isAuthenticated, isFalse);
      expect(authController.errorMessage, equals('Password cannot be empty'));
      expect(mockAuthService.signInCallCount, equals(0));
    });

    test('handles service exception gracefully', () async {
      mockAuthService.shouldThrowError = true;

      final result = await authController.login('test@example.com', 'password123');

      expect(result, isFalse);
      expect(authController.isAuthenticated, isFalse);
      expect(authController.errorMessage, contains('An error occurred'));
    });
  });

  group('AuthController - No Real Network Calls', () {
    test('verify mock is used and no real calls are made', () async {
      final mockService = MockAuthService();
      final controller = AuthController(mockService);
      
      expect(mockService.signInCallCount, equals(0));

      await controller.login('test@example.com', 'password123');

      expect(mockService.signInCallCount, equals(1));
      
      final stopwatch = Stopwatch()..start();
      await controller.login('test@example.com', 'password123');
      stopwatch.stop();
      
      expect(stopwatch.elapsedMilliseconds, lessThan(100));
    });

    test('multiple login attempts increment call count', () async {
      final mockService = MockAuthService();
      final controller = AuthController(mockService);

      await controller.login('user1@test.com', 'pass1');
      await controller.login('user2@test.com', 'pass2');
      await controller.login('user3@test.com', 'pass3');

      expect(mockService.signInCallCount, equals(3));
    });
  });

  group('MockAuthService behavior verification', () {
    test('mock can simulate success', () async {
      final mock = MockAuthService()..shouldSucceed = true;

      final result = await mock.signIn('any@email.com', 'anypass');

      expect(result, isTrue);
    });

    test('mock can simulate failure', () async {
      final mock = MockAuthService()..shouldSucceed = false;

      final result = await mock.signIn('any@email.com', 'anypass');

      expect(result, isFalse);
    });

    test('mock can simulate errors', () async {
      final mock = MockAuthService()..shouldThrowError = true;

      expect(
        () => mock.signIn('any@email.com', 'anypass'),
        throwsException,
      );
    });
  });
}
