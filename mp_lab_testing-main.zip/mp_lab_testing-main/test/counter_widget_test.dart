import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mp_lab_testing/screens/counter_screen.dart';

void main() {
  group('CounterScreen Widget Tests', () {
    testWidgets('displays initial counter value as 0', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: CounterScreen(),
        ),
      );

      expect(find.text('0'), findsOneWidget);
      expect(find.text('1'), findsNothing);
    });

    testWidgets('increments counter when increment button is tapped', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: CounterScreen(),
        ),
      );

      await tester.tap(find.byKey(const Key('increment_button')));
      await tester.pump();

      expect(find.text('0'), findsNothing);
      expect(find.text('1'), findsOneWidget);
    });

    testWidgets('increments counter multiple times', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: CounterScreen(),
        ),
      );

      await tester.tap(find.byKey(const Key('increment_button')));
      await tester.pump();
      await tester.tap(find.byKey(const Key('increment_button')));
      await tester.pump();
      await tester.tap(find.byKey(const Key('increment_button')));
      await tester.pump();

      expect(find.text('3'), findsOneWidget);
    });

    testWidgets('decrements counter when decrement button is tapped', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: CounterScreen(),
        ),
      );

      await tester.tap(find.byKey(const Key('decrement_button')));
      await tester.pump();

      expect(find.text('-1'), findsOneWidget);
    });

    testWidgets('resets counter to 0 when reset button is tapped', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: CounterScreen(),
        ),
      );

      for (int i = 0; i < 5; i++) {
        await tester.tap(find.byKey(const Key('increment_button')));
        await tester.pump();
      }
      expect(find.text('5'), findsOneWidget);

      await tester.tap(find.byKey(const Key('reset_button')));
      await tester.pump();

      expect(find.text('0'), findsOneWidget);
      expect(find.text('5'), findsNothing);
    });

    testWidgets('UI elements are present', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: CounterScreen(),
        ),
      );

      expect(find.text('You have pushed the button this many times:'), findsOneWidget);
      expect(find.byKey(const Key('increment_button')), findsOneWidget);
      expect(find.byKey(const Key('decrement_button')), findsOneWidget);
      expect(find.byKey(const Key('reset_button')), findsOneWidget);
      expect(find.byIcon(Icons.add), findsOneWidget);
      expect(find.byIcon(Icons.remove), findsOneWidget);
      expect(find.byIcon(Icons.refresh), findsOneWidget);
    });

    testWidgets('complex interaction sequence', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: CounterScreen(),
        ),
      );

      await tester.tap(find.byKey(const Key('increment_button')));
      await tester.pump();

      await tester.tap(find.byKey(const Key('increment_button')));
      await tester.pump();

      await tester.tap(find.byKey(const Key('decrement_button')));
      await tester.pump();

      await tester.tap(find.byKey(const Key('increment_button')));
      await tester.pump();

      expect(find.text('2'), findsOneWidget);
    });
  });
}
